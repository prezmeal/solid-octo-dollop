#pragma once

namespace AndroidProp {

    const char* GetRelease();

    int GetApiLevel();

    int GetPreviewApiLevel();
}