#pragma once

#define CONFIG_DIR "/data/adb/riru"
#define SOCKET_ADDRESS "rirud"