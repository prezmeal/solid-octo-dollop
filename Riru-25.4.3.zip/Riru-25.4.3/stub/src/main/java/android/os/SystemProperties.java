package android.os;

public class SystemProperties {

    public static String get(String key) {
        throw new RuntimeException("STUB");
    }

    public static void set(String key, String value) {
        throw new RuntimeException("STUB");
    }
}
